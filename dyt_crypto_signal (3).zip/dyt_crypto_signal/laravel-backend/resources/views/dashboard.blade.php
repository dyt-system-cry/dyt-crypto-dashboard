<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DYT Crypto Signal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lightweight-charts@3.8.0/dist/lightweight-charts.standalone.production.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;700&display=swap');
        body { font-family: 'Inter', sans-serif; background-color: #0d1117; color: #c9d1d9; }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
        .glass-panel { background: rgba(22, 27, 34, 0.7); backdrop-filter: blur(12px); border: 1px solid rgba(255,255,255,0.05); }
        .neon-buy { text-shadow: 0 0 10px rgba(16, 185, 129, 0.6); }
        .neon-sell { text-shadow: 0 0 10px rgba(239, 68, 68, 0.6); }
        
        /* Custom scrollbar for compactness */
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: rgba(0,0,0,0.1); }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }
        ::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.2); }
    </style>
</head>
<body class="antialiased min-h-screen flex flex-col" x-data="tradingDashboard()">

    <!-- Navbar -->
    <nav class="glass-panel px-4 py-2.5 flex justify-between items-center z-10 sticky top-0 border-b border-gray-800 shadow-md">
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-500 to-purple-600 flex items-center justify-center font-bold text-white text-xs shadow-[0_0_10px_rgba(59,130,246,0.5)]">DYT</div>
            <div class="flex flex-col">
                <h1 class="text-lg font-bold tracking-wider text-white">DYT Crypto<span class="text-blue-400">Signal</span></h1>
                <span class="text-[10px] text-gray-500 font-medium">Created by Ruwan</span>
            </div>
        </div>
        
        <!-- Tabs centered in Navbar -->
        <div class="hidden md:flex items-center gap-1 bg-gray-900 p-1 rounded-lg border border-gray-700">
            <button @click="activeTab = 'dashboard'" :class="activeTab === 'dashboard' ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'" class="px-4 py-1.5 text-xs font-semibold rounded transition">Dashboard</button>
            <button @click="activeTab = 'history'" :class="activeTab === 'history' ? 'bg-gray-800 text-white shadow-sm' : 'text-gray-400 hover:text-white'" class="px-4 py-1.5 text-xs font-semibold rounded transition">Saved Signals</button>
        </div>

        <div class="flex items-center gap-2">
            <select x-model="symbol" @change="onCoinSelect()" class="bg-gray-800 border border-gray-700 text-white text-xs rounded focus:ring-blue-500 focus:border-blue-500 block p-1.5 outline-none font-mono hover:bg-gray-700 transition">
                <template x-for="coin in coins" :key="coin">
                    <option :value="coin" x-text="coin"></option>
                </template>
            </select>
            <select x-model="interval" @change="fetchData(); scanMarkets();" class="bg-gray-800 border border-gray-700 text-white text-xs rounded focus:ring-blue-500 focus:border-blue-500 block p-1.5 outline-none font-mono hover:bg-gray-700 transition">
                <template x-for="tf in intervals" :key="tf">
                    <option :value="tf" x-text="tf"></option>
                </template>
            </select>
            <div class="px-3 py-1.5 ml-2 rounded bg-gray-800 border border-gray-700 flex items-center gap-2">
                <div class="w-2 h-2 rounded-full" :class="loading || mtfScanning ? 'bg-yellow-400 animate-pulse' : 'bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.8)]'"></div>
                <span class="text-xs font-medium hidden sm:inline" x-text="mtfScanning ? 'Auto-Scanning...' : (loading ? 'Analyzing...' : 'System Online')"></span>
            </div>
            
            <!-- Toast Notification Container -->
            <div x-show="toast.show" x-transition class="absolute top-16 right-4 bg-gray-800 border border-gray-600 shadow-xl rounded-lg p-3 flex items-center gap-3 z-50">
                <div class="w-2 h-full rounded-full" :class="toast.type === 'BUY' ? 'bg-green-500' : (toast.type === 'SELL' ? 'bg-red-500' : (toast.type === 'WARNING' ? 'bg-yellow-500' : 'bg-blue-500'))"></div>
                <div>
                    <div class="text-xs text-gray-400 font-bold uppercase" x-text="toast.title"></div>
                    <div class="text-sm text-white font-mono" x-text="toast.message"></div>
                </div>
            </div>
        </div>
    </nav>
    
    <!-- Mobile Tabs -->
    <div class="flex md:hidden justify-center bg-gray-900 border-b border-gray-800">
        <button @click="activeTab = 'dashboard'" :class="activeTab === 'dashboard' ? 'border-b-2 border-blue-500 text-white' : 'text-gray-500'" class="px-6 py-3 text-xs font-semibold transition">Dashboard</button>
        <button @click="activeTab = 'history'" :class="activeTab === 'history' ? 'border-b-2 border-blue-500 text-white' : 'text-gray-500'" class="px-6 py-3 text-xs font-semibold transition">Saved Signals</button>
    </div>

    <!-- DASHBOARD TAB -->
    <main x-show="activeTab === 'dashboard'" class="flex-1 p-4 grid grid-cols-12 gap-4">
        
        <!-- Left Column: Chart & History -->
        <div class="col-span-12 xl:col-span-9 flex flex-col gap-4 h-full">
            <!-- Chart Container -->
            <div class="glass-panel rounded-lg p-3 flex-1 flex flex-col relative shadow-md min-h-[350px]">
                <div class="flex justify-between items-center mb-2">
                    <h2 class="text-base font-semibold text-white flex items-center gap-2">
                        <span x-text="symbol"></span> <span class="text-gray-400 text-xs font-normal" x-text="interval + ' / Binance Live'"></span>
                    </h2>
                </div>
                <div id="tvchart" class="flex-1 w-full relative z-0"></div>
                <!-- Loading overlay -->
                <div x-show="loading || mtfScanning" class="absolute inset-0 z-20 flex items-center justify-center bg-[#0d1117]/80 backdrop-blur-sm rounded-lg">
                    <div class="animate-spin w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full"></div>
                </div>
            </div>

            <!-- Market Scanner Table -->
            <div class="glass-panel rounded-lg p-3 h-48 overflow-y-auto shadow-md">
                <div class="flex justify-between items-center mb-3">
                    <h2 class="text-sm font-semibold text-white uppercase tracking-wider">Live Market Scanner</h2>
                    <span class="text-[10px] text-blue-400 bg-blue-400/10 px-2 py-0.5 rounded font-mono" x-show="scanning">Scanning 20 Coins...</span>
                </div>
                <table class="w-full text-xs text-left">
                    <thead class="text-[10px] text-gray-400 uppercase bg-gray-800/50">
                        <tr>
                            <th class="px-3 py-2 rounded-tl">Symbol</th>
                            <th class="px-3 py-2">Signal</th>
                            <th class="px-3 py-2">Strategy Output</th>
                            <th class="px-3 py-2 text-right">Confidence</th>
                            <th class="px-3 py-2 text-right rounded-tr">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="sig in activeSignals" :key="sig.symbol">
                            <tr class="border-b border-gray-800/50 hover:bg-gray-800/30 transition cursor-pointer" @click="symbol = sig.symbol; onCoinSelect()">
                                <td class="px-3 py-2 font-bold text-white flex items-center gap-2">
                                    <span x-text="sig.symbol"></span>
                                    <span x-show="sig.symbol === symbol" class="w-1.5 h-1.5 rounded-full bg-blue-500 shadow-[0_0_5px_rgba(59,130,246,0.8)]"></span>
                                </td>
                                <td class="px-3 py-2">
                                    <span class="px-1.5 py-0.5 rounded text-[10px] font-bold" 
                                          :class="{
                                            'bg-green-500/20 text-green-400 border border-green-500/30': sig.signal === 'BUY',
                                            'bg-red-500/20 text-red-400 border border-red-500/30': sig.signal === 'SELL'
                                          }" x-text="sig.signal"></span>
                                </td>
                                <td class="px-3 py-2 text-gray-400 text-[10px]" x-text="sig.metadata.reason"></td>
                                <td class="px-3 py-2 text-right font-mono text-blue-300" x-text="sig.ai_confidence + '%'"></td>
                                <td class="px-3 py-2 text-right">
                                    <button class="text-[10px] text-white bg-blue-600 hover:bg-blue-500 px-2 py-1 rounded transition">View</button>
                                </td>
                            </tr>
                        </template>
                        <tr x-show="activeSignals.length === 0 && !scanning">
                            <td colspan="5" class="px-3 py-6 text-center text-gray-500 text-xs italic">
                                No highly probable entries found. Waiting for configurations...
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Right Column: Signal Data & Risk Mgmt -->
        <div class="col-span-12 xl:col-span-3 flex flex-col gap-4">
            
            <!-- Current Signal Card -->
            <div class="glass-panel rounded-lg p-4 relative overflow-hidden flex flex-col items-center justify-center text-center shadow-md min-h-[140px]">
                <div class="absolute inset-0 opacity-10 transition-colors duration-1000"
                     :class="{
                        'bg-green-500': signalData?.signal === 'BUY',
                        'bg-red-500': signalData?.signal === 'SELL',
                        'bg-gray-500': !signalData?.signal || signalData?.signal == 'NEUTRAL'
                     }"></div>
                
                <h3 class="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1 z-10" x-text="symbol + ' Signal (' + interval + ')'"></h3>
                
                <div class="text-2xl font-extrabold tracking-tight z-10 transition-colors"
                     :class="{
                        'text-green-400 neon-buy': signalData?.signal === 'BUY',
                        'text-red-500 neon-sell': signalData?.signal === 'SELL',
                        'text-gray-300': !signalData?.signal || signalData?.signal == 'NEUTRAL'
                     }"
                     x-text="signalData?.signal === 'NEUTRAL' ? 'WAITING' : (signalData?.signal || 'WAITING')"></div>
                     
                <div class="mt-3 flex gap-2 w-full z-10">
                    <div class="flex-1 bg-black/40 rounded p-1 border border-white/5">
                        <div class="text-[9px] text-gray-400 truncate">AI Conf.</div>
                        <div class="text-sm font-bold font-mono text-white" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? signalData.ai_confidence + '%' : '--'"></div>
                    </div>
                    <div class="flex-1 bg-black/40 rounded p-1 border border-white/5">
                        <div class="text-[9px] text-gray-400 truncate">Order Book</div>
                        <div class="text-xs mt-0.5 font-bold font-mono" 
                             :class="{'text-green-400': orderBook.ratio >= 55, 'text-red-400': orderBook.ratio <= 45, 'text-gray-300': orderBook.ratio > 45 && orderBook.ratio < 55}" 
                             x-text="orderBook.ratio + '% BUY'"></div>
                    </div>
                    <div class="flex-1 bg-black/40 rounded p-1 border border-white/5">
                        <div class="text-[9px] text-gray-400 truncate">News Bias</div>
                        <div class="text-[10px] mt-1 font-bold font-mono uppercase" 
                             :class="{'text-green-400': newsSentiment.score >= 30, 'text-red-400': newsSentiment.score <= -30, 'text-gray-300': newsSentiment.score > -30 && newsSentiment.score < 30}" 
                             x-text="newsSentiment.status"></div>
                    </div>
                </div>

                <!-- Early Exit Warning -->
                <div x-show="exitWarning" class="mt-3 p-2 bg-red-500/20 border border-red-500 rounded text-center animate-pulse z-10 w-full">
                    <div class="text-[10px] text-red-300 font-bold uppercase mb-0.5">⚠️ Early Exit Warning ⚠️</div>
                    <div class="text-[10px] text-white">Contradicting Fundamental News Detected. Consider closing trade to prevent loss.</div>
                </div>
            </div>

            <!-- Risk Management Widget -->
            <div class="glass-panel rounded-lg p-0 overflow-hidden shadow-md flex-1">
                <div class="bg-gray-800/80 p-2.5 border-b border-white/5 flex justify-between items-center">
                    <h3 class="text-xs font-bold text-white uppercase tracking-wider">Trade Execution</h3>
                </div>
                
                <div class="p-3 flex flex-col gap-3 text-xs">
                    <div class="flex justify-between items-center bg-white/5 p-1.5 rounded">
                        <span class="text-gray-400">Entry Price</span>
                        <span class="font-mono font-bold text-white" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? '$' + signalData.entry : '--'"></span>
                    </div>
                    
                    <div class="flex justify-between items-center group px-1">
                        <div class="flex items-center gap-1.5">
                            <div class="w-1.5 h-1.5 rounded-full bg-red-500"></div>
                            <span class="text-gray-300">Stop Loss</span>
                        </div>
                        <div class="text-right">
                            <div class="font-mono font-bold text-red-400" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? '$' + signalData.sl : '--'"></div>
                            <div class="text-[9px] text-red-400/80" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? calcPercent(signalData.sl, signalData.entry, signalData.signal) : ''"></div>
                        </div>
                    </div>
                    
                    <div class="flex justify-between items-center group px-1">
                        <div class="flex items-center gap-1.5">
                            <div class="w-1.5 h-1.5 rounded-full bg-green-400"></div>
                            <span class="text-gray-300">Take Profit 1</span>
                        </div>
                        <div class="text-right">
                            <div class="font-mono font-bold text-green-400" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? '$' + signalData.tp1 : '--'"></div>
                            <div class="text-[9px] text-green-400/80" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? calcPercent(signalData.tp1, signalData.entry, signalData.signal) : ''"></div>
                        </div>
                    </div>

                    <div class="flex justify-between items-center group px-1">
                        <div class="flex items-center gap-1.5">
                            <div class="w-1.5 h-1.5 rounded-full bg-green-500"></div>
                            <span class="text-gray-300">Take Profit 2</span>
                        </div>
                        <div class="text-right">
                            <div class="font-mono font-bold text-green-500" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? '$' + signalData.tp2 : '--'"></div>
                            <div class="text-[9px] text-green-500/80" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? calcPercent(signalData.tp2, signalData.entry, signalData.signal) : ''"></div>
                        </div>
                    </div>

                    <div class="flex justify-between items-center group px-1">
                        <div class="flex items-center gap-1.5">
                            <div class="w-1.5 h-1.5 rounded-full bg-green-600"></div>
                            <span class="text-gray-300">Take Profit 3</span>
                        </div>
                        <div class="text-right">
                            <div class="font-mono font-bold text-green-600" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? '$' + signalData.tp3 : '--'"></div>
                            <div class="text-[9px] text-green-600/80" x-text="(signalData && signalData.signal !== 'NEUTRAL') ? calcPercent(signalData.tp3, signalData.entry, signalData.signal) : ''"></div>
                        </div>
                    </div>
                </div>

                <!-- Technicals -->
                <div class="bg-[#090b0e] p-3 border-t border-white/5 h-full">
                    <div class="grid grid-cols-2 gap-2">
                        <div class="bg-gray-800/40 p-1.5 rounded text-center">
                            <div class="text-[9px] text-gray-500 uppercase">RSI (14)</div>
                            <div class="font-mono text-xs" :class="{'text-red-400': signalData?.metadata?.rsi > 70, 'text-green-400': signalData?.metadata?.rsi < 30, 'text-white': signalData?.metadata?.rsi >= 30 && signalData?.metadata?.rsi <= 70}" x-text="signalData ? signalData.metadata.rsi : '--'"></div>
                        </div>
                        <div class="bg-gray-800/40 p-1.5 rounded text-center">
                            <div class="text-[9px] text-gray-500 uppercase">Vol Spike</div>
                            <div class="font-mono text-xs" :class="signalData?.metadata?.volume_spike ? 'text-green-400' : 'text-gray-400'" x-text="signalData ? (signalData.metadata.volume_spike ? 'YES' : 'NO') : '--'"></div>
                        </div>
                    </div>
                    <div class="mt-2 text-center text-[10px] text-blue-400" x-text="signalData?.metadata?.reason || 'Scanning for setups...'"></div>
                </div>
            </div>
        </div>
    </main>

    <!-- HISTORY TAB -->
    <main x-show="activeTab === 'history'" class="flex-1 p-6 relative" style="display: none;">
        
        <!-- Modal Overlay for History Details -->
        <div x-show="selectedHistoryLog" class="absolute inset-0 z-50 flex items-center justify-center bg-[#0d1117]/80 backdrop-blur-sm" style="display: none;" x-transition.opacity>
            <div class="glass-panel p-6 rounded-lg w-full max-w-sm shadow-2xl relative border border-gray-700 bg-gray-900/90" @click.away="selectedHistoryLog = null">
                <button @click="selectedHistoryLog = null" class="absolute top-4 right-4 text-gray-400 hover:text-white transition">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
                
                <h2 class="text-base font-bold text-white mb-1 uppercase tracking-wider">Trade Setup</h2>
                <p class="text-[10px] text-gray-400 mb-5 font-mono" x-text="selectedHistoryLog?.time + ' (IST)'"></p>
                
                <div class="flex items-center justify-between mb-5 bg-black/30 p-2 rounded border border-white/5">
                    <span class="px-2.5 py-1 rounded text-xs font-bold" :class="selectedHistoryLog?.signal === 'BUY' ? 'bg-green-500/20 text-green-400 border border-green-500/30' : 'bg-red-500/20 text-red-400 border border-red-500/30'" x-text="selectedHistoryLog?.signal"></span>
                    <div class="text-right">
                        <div class="text-[9px] text-gray-500 uppercase">AI Confidence</div>
                        <div class="text-sm font-mono text-white font-bold" x-text="selectedHistoryLog?.ai_confidence + '%'"></div>
                    </div>
                </div>
                
                <div class="space-y-3 text-xs mb-6">
                    <div class="flex justify-between items-center border-b border-gray-800 pb-2">
                        <span class="text-gray-400">Entry Price</span>
                        <span class="text-white font-mono font-bold" x-text="'$' + selectedHistoryLog?.entry"></span>
                    </div>
                    <div class="flex justify-between items-center border-b border-gray-800 pb-2">
                        <span class="text-red-400 flex items-center gap-1.5"><div class="w-1.5 h-1.5 rounded-full bg-red-500"></div>Stop Loss</span>
                        <span class="text-red-400 font-mono" x-text="'$' + selectedHistoryLog?.sl"></span>
                    </div>
                    <div class="flex justify-between items-center border-b border-gray-800 pb-2">
                        <span class="text-green-400 flex items-center gap-1.5"><div class="w-1.5 h-1.5 rounded-full bg-green-400"></div>Take Profit 1</span>
                        <span class="text-green-400 font-mono" x-text="'$' + selectedHistoryLog?.tp1"></span>
                    </div>
                    <div class="flex justify-between items-center border-b border-gray-800 pb-2">
                        <span class="text-green-500 flex items-center gap-1.5"><div class="w-1.5 h-1.5 rounded-full bg-green-500"></div>Take Profit 2</span>
                        <span class="text-green-500 font-mono" x-text="'$' + selectedHistoryLog?.tp2"></span>
                    </div>
                    <div class="flex justify-between items-center pb-2">
                        <span class="text-green-600 flex items-center gap-1.5"><div class="w-1.5 h-1.5 rounded-full bg-green-600"></div>Take Profit 3</span>
                        <span class="text-green-600 font-mono font-bold" x-text="'$' + selectedHistoryLog?.tp3"></span>
                    </div>
                </div>
                
                <div class="mt-2 p-3 rounded border" :class="selectedHistoryLog?.status.includes('WIN') ? 'bg-green-500/10 border-green-500/20' : (selectedHistoryLog?.status.includes('LOSS') ? 'bg-red-500/10 border-red-500/20' : 'bg-blue-500/10 border-blue-500/20')">
                    <div class="flex justify-between items-center">
                        <span class="text-[10px] text-gray-400 uppercase tracking-wider">Outcome</span>
                        <span class="font-bold text-sm" 
                              :class="{
                                  'text-green-400': selectedHistoryLog?.status.includes('WIN'),
                                  'text-red-400': selectedHistoryLog?.status.includes('LOSS'),
                                  'text-blue-400': selectedHistoryLog?.status === 'PENDING'
                              }" 
                              x-text="selectedHistoryLog?.status"></span>
                    </div>
                </div>
            </div>
        </div>

        <div class="glass-panel rounded-lg p-0 overflow-hidden shadow-md max-w-5xl mx-auto flex flex-col h-[85vh]">
            <div class="bg-gray-800/80 p-4 border-b border-white/5 flex justify-between items-center">
                <div>
                    <h3 class="text-lg font-bold text-white tracking-wider flex items-center gap-2">
                        Saved Signals
                    </h3>
                    <span class="text-xs text-gray-400">Live signals tracked across all coins. Cleared after 3 days.</span>
                </div>
                <div class="flex gap-4 text-center">
                    <div class="bg-black/30 px-4 py-2 rounded border border-white/5">
                        <div class="text-[10px] text-gray-400 uppercase">Total Saved</div>
                        <div class="font-mono font-bold text-blue-300 text-lg" x-text="savedSignals.length"></div>
                    </div>
                </div>
            </div>

            <!-- Full History Table -->
            <div class="flex-1 overflow-y-auto bg-[#0d1117]/50">
                <table class="w-full text-left text-sm">
                    <thead class="text-gray-400 uppercase text-[10px] tracking-wider sticky top-0 bg-gray-900 border-b border-gray-800 z-10">
                        <tr>
                            <th class="px-6 py-4 font-semibold">Date & Time</th>
                            <th class="px-6 py-4 font-semibold">Coin / TF</th>
                            <th class="px-6 py-4 font-semibold">Signal</th>
                            <th class="px-6 py-4 font-semibold">Entry Price</th>
                            <th class="px-6 py-4 font-semibold text-right">Status</th>
                            <th class="px-6 py-4 font-semibold text-right">Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <template x-for="log in savedSignals" :key="log.id">
                            <tr class="border-b border-gray-800/50 hover:bg-gray-800/40 transition">
                                <td class="px-6 py-3 text-gray-300 font-mono text-[11px]" x-text="log.timeStr"></td>
                                <td class="px-6 py-3 text-gray-300 font-mono text-[11px] font-bold">
                                    <span x-text="log.symbol"></span> <span class="text-gray-500 font-normal" x-text="log.interval"></span>
                                </td>
                                <td class="px-6 py-3 font-bold" :class="log.signal === 'BUY' ? 'text-green-400' : 'text-red-400'">
                                    <span class="px-2 py-1 rounded text-[10px] tracking-wider bg-opacity-20" :class="log.signal === 'BUY' ? 'bg-green-500' : 'bg-red-500'" x-text="log.signal"></span>
                                </td>
                                <td class="px-6 py-3 font-mono text-gray-100 text-xs" x-text="'$' + log.entry"></td>
                                <td class="px-6 py-3 font-bold text-right">
                                    <span class="px-3 py-1 rounded text-[10px] border"
                                          :class="{
                                              'bg-green-500/10 text-green-400 border-green-500/20': log.status.includes('WIN'),
                                              'bg-red-500/10 text-red-400 border-red-500/20': log.status.includes('LOSS'),
                                              'bg-blue-500/10 text-blue-400 border-blue-500/20': log.status === 'PENDING'
                                          }" x-text="log.status"></span>
                                </td>
                                <td class="px-6 py-3 text-right">
                                    <button @click="selectedHistoryLog = log" class="text-[10px] text-white bg-blue-600 hover:bg-blue-500 px-3 py-1.5 rounded transition shadow-sm font-medium">View Setup</button>
                                </td>
                            </tr>
                        </template>
                        <tr x-show="savedSignals.length === 0">
                            <td colspan="6" class="px-6 py-10 text-center text-gray-500">
                                <div class="flex flex-col items-center justify-center">
                                    <svg class="w-12 h-12 mb-3 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"></path></svg>
                                    <p class="font-medium text-gray-400">No signals saved yet.</p>
                                    <p class="text-xs text-gray-500 mt-1">Live signals will appear here automatically.</p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Notification Sound -->
    <audio id="notifySound" src="https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3" preload="auto"></audio>

    <script>
        document.addEventListener('alpine:init', () => {
            Alpine.data('tradingDashboard', () => {
                let chart = null;
                let candleSeries = null;
                let lines = { entry: null, sl: null, tp1: null, tp2: null, tp3: null };
                let wsConnection = null;
                let lastSignalState = 'WAITING';

                // Core TA Library
                const runStrictTA = (klineArray) => {
                    if (klineArray.length < 100) return { signal: 'NEUTRAL', reasonStr: 'Insufficient Data' };
                    
                    const closes = klineArray.map(k => k.close);
                    const highs = klineArray.map(k => k.high);
                    const lows = klineArray.map(k => k.low);
                    
                    const calcRSI = (data, p) => {
                        let gains = 0, losses = 0;
                        for(let i=1; i<=p; i++) {
                            let diff = data[i] - data[i-1];
                            if(diff >= 0) gains += diff; else losses -= diff;
                        }
                        let avgG = gains/p, avgL = losses/p;
                        for(let i=p+1; i<data.length; i++) {
                            let diff = data[i] - data[i-1];
                            avgG = (avgG*(p-1) + (diff>=0?diff:0))/p;
                            avgL = (avgL*(p-1) + (diff<0?-diff:0))/p;
                        }
                        return avgL === 0 ? 100 : 100 - (100 / (1 + (avgG/avgL)));
                    };

                    const rsiValue = calcRSI(closes, 14);
                    const lastClose = closes[closes.length - 1];
                    const prevClose = closes[closes.length - 2];
                    
                    const recentLows = lows.slice(-100);
                    const recentHighs = highs.slice(-100);
                    const support = Math.min(...recentLows);
                    const resistance = Math.max(...recentHighs);
                    const priceRange = resistance - support;
                    
                    const positionInRange = priceRange === 0 ? 0.5 : (lastClose - support) / priceRange;
                    
                    let signal = 'NEUTRAL';
                    let reasonStr = 'Price in neutral zone';
                    let tempSL = 0, tempTP1 = 0, tempTP2 = 0, tempTP3 = 0;
                    
                    if (positionInRange <= 0.20 && rsiValue < 40) {
                        signal = 'BUY';
                        reasonStr = 'Support Accumulation Phase';
                        tempSL = support - (priceRange * 0.05);
                        tempTP1 = support + (priceRange * 0.25);
                        tempTP2 = support + (priceRange * 0.50);
                        tempTP3 = support + (priceRange * 0.80);
                    } else if (positionInRange >= 0.80 && rsiValue > 60) {
                        signal = 'SELL';
                        reasonStr = 'Resistance Distribution Phase';
                        tempSL = resistance + (priceRange * 0.05);
                        tempTP1 = resistance - (priceRange * 0.25);
                        tempTP2 = resistance - (priceRange * 0.50);
                        tempTP3 = resistance - (priceRange * 0.80);
                    }

                    let ai_confidence = (Math.abs(50 - rsiValue) + 50).toFixed(1);
                    if (signal !== 'NEUTRAL' && parseFloat(ai_confidence) < 75) {
                        signal = 'NEUTRAL';
                        reasonStr = 'Low confidence (Wait for >75%)';
                    }

                    return {
                        signal,
                        entryTime: klineArray[klineArray.length - 1].time,
                        entry: parseFloat(lastClose.toPrecision(6)),
                        sl: parseFloat(tempSL.toPrecision(6)),
                        tp1: parseFloat(tempTP1.toPrecision(6)),
                        tp2: parseFloat(tempTP2.toPrecision(6)),
                        tp3: parseFloat(tempTP3.toPrecision(6)),
                        ai_confidence: ai_confidence,
                        metadata: { rsi: Math.floor(rsiValue), volume_spike: (Math.abs(lastClose - prevClose) > lastClose*0.01), reason: reasonStr }
                    };
                };

                return {
                    coins: ['BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT','ADAUSDT','AVAXUSDT','DOGEUSDT','DOTUSDT','LINKUSDT','MATICUSDT','SHIBUSDT','LTCUSDT','ATOMUSDT','NEARUSDT','BCHUSDT','ALGOUSDT','VETUSDT','FTMUSDT','OPUSDT','INJUSDT','RNDRUSDT','ARBUSDT','APTUSDT','SUIUSDT','FETUSDT','FILUSDT','LDOUSDT','STXUSDT','IMXUSDT','SANDUSDT','MANAUSDT','AAVEUSDT','MKRUSDT','SNXUSDT','GRTUSDT','THETAUSDT','AXSUSDT','EGLDUSDT','QNTUSDT','CHZUSDT','ZILUSDT','ENJUSDT','CRVUSDT','DYDXUSDT','GALAUSDT','PEPEUSDT','FLOKIUSDT','WLDUSDT','SEIUSDT'],
                    intervals: ['5m', '15m', '30m', '1h', '2h', '4h', '1d'],
                    symbol: 'BTCUSDT',
                    interval: '15m',
                    activeTab: 'dashboard',
                    loading: false,
                    scanning: false,
                    mtfScanning: false,
                    signalData: null,
                    activeSignals: [],
                    activeTradeLock: null,
                    savedSignals: JSON.parse(localStorage.getItem('dyt_saved_signals')) || [],
                    orderBook: { buyVol: 0, sellVol: 0, ratio: 50, status: 'NEUTRAL' },
                    newsSentiment: { score: 0, status: 'NEUTRAL' },
                    exitWarning: false,
                    selectedHistoryLog: null,
                    calcPercent(target, entry, type) {
                        if(!entry) return '';
                        let pct = ((target - entry) / entry) * 100;
                        if(type === 'SELL') pct = -pct; 
                        let sign = pct > 0 ? '+' : '';
                        return `[${sign}${pct.toFixed(2)}%]`;
                    },
                    cleanOldSignals() {
                        const threeDays = 3 * 24 * 60 * 60 * 1000;
                        this.savedSignals = this.savedSignals.filter(s => (Date.now() - s.timestamp) < threeDays);
                        localStorage.setItem('dyt_saved_signals', JSON.stringify(this.savedSignals));
                    },
                    bgScanner: null,
                    toast: { show: false, title: '', message: '', type: 'BUY' },
                    backtestStats: { total: 0, wins: 0, losses: 0, winRate: 0, loading: false, historyLog: [] },

                    init() {
                        if ("Notification" in window) Notification.requestPermission();

                        this.$nextTick(() => {
                            const tvChartEl = document.getElementById('tvchart');
                            if (tvChartEl) {
                                chart = LightweightCharts.createChart(tvChartEl, { 
                                    layout: { textColor: '#d1cece', background: { type: 'solid', color: 'transparent' } },
                                    grid: { vertLines: { color: 'rgba(42, 46, 57, 0.3)' }, horzLines: { color: 'rgba(42, 46, 57, 0.3)' } },
                                    crosshair: { mode: LightweightCharts.CrosshairMode.Normal },
                                    rightPriceScale: { borderColor: 'rgba(197, 203, 206, 0.4)' },
                                    timeScale: { borderColor: 'rgba(197, 203, 206, 0.4)' },
                                    width: tvChartEl.clientWidth,
                                    height: tvChartEl.clientHeight || 350
                                });
                                candleSeries = chart.addCandlestickSeries({
                                    upColor: '#26a69a', downColor: '#ef5350', borderVisible: false,
                                    wickUpColor: '#26a69a', wickDownColor: '#ef5350'
                                });
                                window.addEventListener('resize', () => {
                                    if (chart && this.activeTab === 'dashboard') {
                                        chart.applyOptions({ width: tvChartEl.clientWidth, height: tvChartEl.clientHeight });
                                    }
                                });
                                
                                this.$watch('activeTab', value => {
                                    if (value === 'dashboard') {
                                        setTimeout(() => {
                                            chart.applyOptions({ width: tvChartEl.clientWidth, height: tvChartEl.clientHeight });
                                        }, 50);
                                    }
                                });
                            }

                            this.onCoinSelect(); 
                            this.scanMarkets();
                            
                            setInterval(() => this.fetchData(), 120000);
                            setInterval(() => this.fetchNewsSentiment(), 180000); // Check news every 3 mins
                            setInterval(() => this.fetchOrderBook(), 10000); // Check Live Order Book every 10s
                            this.bgScanner = setInterval(() => this.scanMarkets(), 180000);
                        });
                    },

                    async fetchOrderBook() {
                        try {
                            const res = await fetch(`https://api.binance.com/api/v3/depth?symbol=${this.symbol}&limit=50`);
                            if(!res.ok) return;
                            const data = await res.json();
                            
                            let buyVol = 0;
                            let sellVol = 0;
                            
                            data.bids.forEach(b => buyVol += (parseFloat(b[0]) * parseFloat(b[1])));
                            data.asks.forEach(a => sellVol += (parseFloat(a[0]) * parseFloat(a[1])));
                            
                            let total = buyVol + sellVol;
                            if(total === 0) return;
                            
                            let ratio = (buyVol / total) * 100;
                            let status = 'NEUTRAL';
                            if (ratio >= 55) status = 'BULLISH';
                            else if (ratio <= 45) status = 'BEARISH';
                            
                            this.orderBook = { buyVol, sellVol, ratio: Math.round(ratio), status };
                        } catch(e) {
                            console.error("Order book fetch error", e);
                        }
                    },

                    triggerNotification(signal, symbol, titleOverride = null) {
                        const audio = document.getElementById('notifySound');
                        if(audio) {
                            audio.volume = 0.5;
                            audio.play().catch(e => console.log('Audio play blocked:', e));
                        }

                        if ("Notification" in window && Notification.permission === "granted") {
                            new Notification(`DYT Signal: ${signal}`, {
                                body: titleOverride || `${symbol} has triggered a high-probability ${signal} signal!`,
                                icon: 'https://cdn-icons-png.flaticon.com/512/2950/2950150.png'
                            });
                        }

                        this.toast = {
                            show: true,
                            title: titleOverride || `NEW ${signal} SIGNAL`,
                            message: `${symbol} entered ${signal} zone.`,
                            type: signal
                        };
                        
                        setTimeout(() => { this.toast.show = false; }, 6000);
                    },

                    async fetchNewsSentiment() {
                        try {
                            let baseSymbol = this.symbol.replace('USDT', '');
                            const res = await fetch(`https://min-api.cryptocompare.com/data/v2/news/?categories=${baseSymbol},Market`);
                            if(!res.ok) return;
                            const data = await res.json();
                            
                            const bullishWords = ['surge', 'rally', 'partnership', 'adopted', 'launch', 'upgrade', 'bullish', 'growth', 'positive', 'breakout', 'buy', 'pump', 'adopt'];
                            const bearishWords = ['hack', 'ban', 'lawsuit', 'crash', 'drop', 'bearish', 'regulatory', 'sec', 'dump', 'investigate', 'inflation', 'sell', 'scam', 'decline'];
                            
                            let score = 0;
                            
                            if (data.Data && data.Data.length > 0) {
                                for (let i = 0; i < Math.min(10, data.Data.length); i++) {
                                    const text = (data.Data[i].title + " " + data.Data[i].body).toLowerCase();
                                    bullishWords.forEach(w => { if(text.includes(w)) score += 10; });
                                    bearishWords.forEach(w => { if(text.includes(w)) score -= 10; });
                                }
                            }
                            
                            score = Math.max(-100, Math.min(100, score));
                            let status = 'NEUTRAL';
                            if (score >= 30) status = 'BULLISH';
                            if (score <= -30) status = 'BEARISH';
                            
                            this.newsSentiment = { score, status };
                            this.checkExitWarning();
                        } catch(e) {
                            console.error("News fetch error", e);
                        }
                    },

                    checkExitWarning() {
                        this.exitWarning = false;
                        if (!this.signalData || this.signalData.signal === 'NEUTRAL') return;
                        
                        if (this.signalData.signal === 'BUY' && this.newsSentiment.score <= -30) {
                            this.exitWarning = true;
                            this.triggerNotification('WARNING', this.symbol, 'Bad News Alert! Consider Exiting BUY Trade');
                        }
                        else if (this.signalData.signal === 'SELL' && this.newsSentiment.score >= 30) {
                            this.exitWarning = true;
                            this.triggerNotification('WARNING', this.symbol, 'Positive News Alert! Consider Exiting SELL Trade');
                        }
                    },

                    async onCoinSelect() {
                        this.mtfScanning = true;
                        
                        const intervalsToScan = ['5m', '15m', '30m', '1h', '4h'];
                        let bestSetup = null;
                        
                        try {
                            const promises = intervalsToScan.map(async (tf) => {
                                try {
                                    const res = await fetch(`https://api.binance.com/api/v3/klines?symbol=${this.symbol}&interval=${tf}&limit=100`);
                                    if(!res.ok) return null;
                                    const data = await res.json();
                                    const klinesArr = data.map(k => ({ open: parseFloat(k[1]), high: parseFloat(k[2]), low: parseFloat(k[3]), close: parseFloat(k[4]) }));
                                    const st = runStrictTA(klinesArr);
                                    if (st.signal !== 'NEUTRAL') {
                                        return { interval: tf, ...st };
                                    }
                                } catch(e) {}
                                return null;
                            });

                            const results = await Promise.all(promises);
                            const validSetups = results.filter(r => r !== null);
                            
                            if (validSetups.length > 0) {
                                validSetups.sort((a,b) => parseFloat(b.ai_confidence) - parseFloat(a.ai_confidence));
                                bestSetup = validSetups[0];
                            }
                        } catch(e) { console.error("MTF Scan failed", e); }
                        
                        this.mtfScanning = false;

                        if (bestSetup && bestSetup.interval !== this.interval) {
                            this.interval = bestSetup.interval;
                            this.triggerNotification('INFO', this.symbol, `Auto-switched to ${bestSetup.interval} for best setup`);
                        }

                        this.fetchOrderBook();
                        this.fetchNewsSentiment();
                        this.fetchData();
                    },

                    async runBacktest() {
                        this.backtestStats.loading = true;
                        try {
                            const res = await fetch(`https://api.binance.com/api/v3/klines?symbol=${this.symbol}&interval=${this.interval}&limit=1000`);
                            if(!res.ok) throw new Error("API err");
                            const data = await res.json();
                            const klines = data.map(k => ({ 
                                time: parseFloat(k[0]), 
                                open: parseFloat(k[1]), high: parseFloat(k[2]), low: parseFloat(k[3]), close: parseFloat(k[4]) 
                            }));
                            
                            let wins = 0;
                            let losses = 0;
                            let historyList = [];
                            
                            for (let i = 100; i < klines.length - 1; i++) {
                                const windowData = klines.slice(i - 100, i);
                                const ta = runStrictTA(windowData);
                                
                                if (ta.signal !== 'NEUTRAL') {
                                    let outcome = null;
                                    let maxHit = 'SL'; 
                                    
                                    let highestHigh = ta.entry;
                                    let lowestLow = ta.entry;
                                    
                                    for (let j = i; j < klines.length; j++) {
                                        const futureCandle = klines[j];
                                        if (ta.signal === 'BUY') {
                                            if (futureCandle.high > highestHigh) highestHigh = futureCandle.high;
                                            if (futureCandle.low <= ta.sl) break; 
                                            if (highestHigh >= ta.tp3) break; 
                                        } else if (ta.signal === 'SELL') {
                                            if (futureCandle.low < lowestLow) lowestLow = futureCandle.low;
                                            if (futureCandle.high >= ta.sl) break; 
                                            if (lowestLow <= ta.tp3) break; 
                                        }
                                    }

                                    if (ta.signal === 'BUY') {
                                        if (highestHigh >= ta.tp3) { outcome = 'WIN'; maxHit = 'TP3'; }
                                        else if (highestHigh >= ta.tp2) { outcome = 'WIN'; maxHit = 'TP2'; }
                                        else if (highestHigh >= ta.tp1) { outcome = 'WIN'; maxHit = 'TP1'; }
                                        else { outcome = 'LOSS'; maxHit = 'SL'; }
                                    } else {
                                        if (lowestLow <= ta.tp3) { outcome = 'WIN'; maxHit = 'TP3'; }
                                        else if (lowestLow <= ta.tp2) { outcome = 'WIN'; maxHit = 'TP2'; }
                                        else if (lowestLow <= ta.tp1) { outcome = 'WIN'; maxHit = 'TP1'; }
                                        else { outcome = 'LOSS'; maxHit = 'SL'; }
                                    }

                                    if (outcome) {
                                        if (outcome === 'WIN') wins++;
                                        else losses++;

                                        const dateObj = new Date(windowData[windowData.length-1].time);
                                        const dateStr = dateObj.toLocaleDateString('en-US', { timeZone: 'Asia/Colombo', month:'short', day:'numeric' });
                                        const timeStr = dateObj.toLocaleTimeString('en-US', { timeZone: 'Asia/Colombo', hour: '2-digit', minute:'2-digit' });
                                        
                                        historyList.unshift({
                                            time: `${dateStr} ${timeStr}`,
                                            interval: this.interval,
                                            signal: ta.signal,
                                            entry: ta.entry,
                                            sl: ta.sl,
                                            tp1: ta.tp1,
                                            tp2: ta.tp2,
                                            tp3: ta.tp3,
                                            ai_confidence: ta.ai_confidence,
                                            maxHit: maxHit
                                        });
                                    }
                                    
                                    i += 5; 
                                }
                            }
                            
                            let total = wins + losses;
                            this.backtestStats = {
                                total: total,
                                wins: wins,
                                losses: losses,
                                winRate: total > 0 ? ((wins / total) * 100).toFixed(1) : 0,
                                historyLog: historyList.slice(0, 100), 
                                loading: false
                            };
                        } catch(e) {
                            console.error(e);
                            this.backtestStats.loading = false;
                        }
                    },

                    async scanMarkets() {
                        this.scanning = true;
                        let newSignals = [];
                        try {
                            let promises = this.coins.map(async (coin) => {
                                try {
                                    const res = await fetch(`https://api.binance.com/api/v3/klines?symbol=${coin}&interval=${this.interval}&limit=100`);
                                    if(!res.ok) return;
                                    const data = await res.json();
                                    const klinesArr = data.map(k => ({
                                        open: parseFloat(k[1]), high: parseFloat(k[2]), low: parseFloat(k[3]), close: parseFloat(k[4])
                                    }));
                                    
                                    const st = runStrictTA(klinesArr);
                                    
                                    // Track Pending Signals
                                    const latestCandle = klinesArr[klinesArr.length - 1];
                                    let modified = false;
                                    this.savedSignals.forEach(s => {
                                        if (s.status === 'PENDING' && s.symbol === coin) {
                                            if (s.signal === 'BUY') {
                                                if (latestCandle.low <= s.sl) { s.status = 'LOSS (SL HIT)'; modified = true; }
                                                else if (latestCandle.high >= s.tp3) { s.status = 'WIN (TP3 HIT)'; modified = true; }
                                                else if (latestCandle.high >= s.tp2) { s.status = 'WIN (TP2 HIT)'; modified = true; }
                                                else if (latestCandle.high >= s.tp1) { s.status = 'WIN (TP1 HIT)'; modified = true; }
                                            } else {
                                                if (latestCandle.high >= s.sl) { s.status = 'LOSS (SL HIT)'; modified = true; }
                                                else if (latestCandle.low <= s.tp3) { s.status = 'WIN (TP3 HIT)'; modified = true; }
                                                else if (latestCandle.low <= s.tp2) { s.status = 'WIN (TP2 HIT)'; modified = true; }
                                                else if (latestCandle.low <= s.tp1) { s.status = 'WIN (TP1 HIT)'; modified = true; }
                                            }
                                        }
                                    });
                                    if (modified) localStorage.setItem('dyt_saved_signals', JSON.stringify(this.savedSignals));

                                    if (st.signal !== 'NEUTRAL') {
                                        newSignals.push({ symbol: coin, ...st });
                                    }
                                } catch(e) {}
                            });
                            
                            await Promise.all(promises);
                            newSignals.sort((a,b) => parseFloat(b.ai_confidence) - parseFloat(a.ai_confidence));
                            this.activeSignals = newSignals;
                        } finally {
                            this.scanning = false;
                        }
                    },

                    async fetchData() {
                        this.loading = true;
                        
                        this.runBacktest();

                        try {
                            let chartData = [];
                            try {
                                const binanceRes = await fetch(`https://api.binance.com/api/v3/klines?symbol=${this.symbol}&interval=${this.interval}&limit=100`);
                                if (!binanceRes.ok) throw new Error("API err");
                                const klines = await binanceRes.json();
                                chartData = klines.map(k => ({
                                    time: Math.floor(k[0] / 1000), 
                                    open: parseFloat(k[1]), high: parseFloat(k[2]), low: parseFloat(k[3]), close: parseFloat(k[4])
                                }));
                                
                                if (wsConnection) wsConnection.close();
                                wsConnection = new WebSocket(`wss://stream.binance.com:9443/ws/${this.symbol.toLowerCase()}@kline_${this.interval}`);
                                wsConnection.onmessage = (e) => {
                                    const msg = JSON.parse(e.data);
                                    if (msg && msg.k) {
                                        candleSeries.update({
                                            time: Math.floor(msg.k.t/1000), open: parseFloat(msg.k.o), high: parseFloat(msg.k.h), low: parseFloat(msg.k.l), close: parseFloat(msg.k.c)
                                        });
                                    }
                                };
                            } catch(e) {
                                let now = Math.floor(Date.now() / 1000);
                                let bp = this.symbol.includes('BTC') ? 64000 : 3500;
                                let spc = this.interval.includes('m') ? parseInt(this.interval)*60 : (this.interval.includes('h') ? parseInt(this.interval)*3600 : 86400);
                                chartData = Array.from({length: 100}).map((_, i) => {
                                    let t = now - (99 - i) * spc;
                                    let phase = i * 0.1;
                                    let o = bp + Math.sin(phase)*150 + Math.random()*50;
                                    let c = bp + Math.sin(phase+0.1)*150 + Math.random()*50;
                                    let h = Math.max(o, c) + Math.random()*50 + 10;
                                    let l = Math.min(o, c) - Math.random()*50 - 10;
                                    return { time: t, open: o, high: h, low: l, close: c };
                                });
                            }
                            
                            chartData.sort((a,b) => a.time - b.time);
                            
                            let currentLivePrice = chartData[chartData.length - 1].close;
                            let prec = 2;
                            if (currentLivePrice < 0.0001) prec = 8;
                            else if (currentLivePrice < 0.01) prec = 6;
                            else if (currentLivePrice < 1) prec = 4;
                            else if (currentLivePrice < 10) prec = 3;
                            
                            candleSeries.applyOptions({
                                priceFormat: {
                                    type: 'price',
                                    precision: prec,
                                    minMove: 1 / Math.pow(10, prec)
                                }
                            });
                            
                            candleSeries.setData(chartData);
                            
                            let liveCandle = chartData[chartData.length - 1];

                            // Trade Lock Evaluation
                            if (this.activeTradeLock && this.activeTradeLock.symbol === this.symbol && this.activeTradeLock.interval === this.interval) {
                                if (this.activeTradeLock.signal === 'BUY') {
                                    if (liveCandle.low <= this.activeTradeLock.sl || liveCandle.high >= this.activeTradeLock.tp3) {
                                        this.activeTradeLock = null; 
                                    }
                                } else if (this.activeTradeLock.signal === 'SELL') {
                                    if (liveCandle.high >= this.activeTradeLock.sl || liveCandle.low <= this.activeTradeLock.tp3) {
                                        this.activeTradeLock = null; 
                                    }
                                }
                            }

                            if (this.activeTradeLock && this.activeTradeLock.symbol === this.symbol && this.activeTradeLock.interval === this.interval) {
                                this.signalData = this.activeTradeLock; // Persist signal
                            } else {
                                const taResult = runStrictTA(chartData);
                                
                                // Liquidity / Order Book Filter Integration
                                let finalSignal = taResult.signal;
                                let finalConf = parseFloat(taResult.ai_confidence);
                                let finalReason = taResult.metadata.reason;

                                if (finalSignal === 'BUY') {
                                    if (this.orderBook.ratio < 45) { 
                                        finalSignal = 'NEUTRAL';
                                        finalReason = 'Liquidity Trap: Heavy Sell Walls Detected';
                                    } else if (this.orderBook.ratio > 60) {
                                        finalConf = Math.min(99, finalConf + 5);
                                        finalReason = 'Power Entry: Supported by Buy Walls';
                                    }
                                } else if (finalSignal === 'SELL') {
                                    if (this.orderBook.ratio > 55) { 
                                        finalSignal = 'NEUTRAL';
                                        finalReason = 'Liquidity Trap: Heavy Buy Walls Detected';
                                    } else if (this.orderBook.ratio < 40) {
                                        finalConf = Math.min(99, finalConf + 5);
                                        finalReason = 'Power Entry: Supported by Sell Walls';
                                    }
                                }

                                this.signalData = { 
                                    symbol: this.symbol, 
                                    ...taResult, 
                                    signal: finalSignal, 
                                    ai_confidence: finalConf.toFixed(1), 
                                    metadata: { ...taResult.metadata, reason: finalReason } 
                                };

                                if (this.signalData.signal !== 'NEUTRAL') {
                                    this.activeTradeLock = { ...this.signalData, interval: this.interval };
                                    this.triggerNotification(this.signalData.signal, this.symbol);
                                    
                                    // Save Signal to LocalStorage
                                    let newSignal = {
                                        id: Date.now(),
                                        symbol: this.symbol,
                                        interval: this.interval,
                                        timeStr: new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Colombo' }),
                                        timestamp: Date.now(),
                                        ...this.activeTradeLock,
                                        status: 'PENDING'
                                    };
                                    this.savedSignals.unshift(newSignal);
                                    this.cleanOldSignals();
                                }
                            }

                            this.checkExitWarning();
                            this.drawChartPriceLines();

                        } catch(e) { console.error(e); } finally { this.loading = false; }
                    },
                    
                    drawChartPriceLines() {
                        if (!candleSeries || !this.signalData) return;
                        
                        if (lines.entry) candleSeries.removePriceLine(lines.entry);
                        if (lines.sl) candleSeries.removePriceLine(lines.sl);
                        if (lines.tp1) candleSeries.removePriceLine(lines.tp1);
                        if (lines.tp2) candleSeries.removePriceLine(lines.tp2);
                        if (lines.tp3) candleSeries.removePriceLine(lines.tp3);
                        
                        if (this.signalData.signal === 'NEUTRAL') return;
                        
                        lines.entry = candleSeries.createPriceLine({ price: this.signalData.entry, color: '#94a3b8', lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Solid, axisLabelVisible: true, title: 'ENTRY' });
                        lines.sl = candleSeries.createPriceLine({ price: this.signalData.sl, color: '#ef4444', lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Solid, axisLabelVisible: true, title: 'SL' });
                        lines.tp1 = candleSeries.createPriceLine({ price: this.signalData.tp1, color: '#4ade80', lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Dashed, axisLabelVisible: true, title: 'TP1' });
                        lines.tp2 = candleSeries.createPriceLine({ price: this.signalData.tp2, color: '#22c55e', lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Dashed, axisLabelVisible: true, title: 'TP2' });
                        lines.tp3 = candleSeries.createPriceLine({ price: this.signalData.tp3, color: '#16a34a', lineWidth: 1, lineStyle: LightweightCharts.LineStyle.Dashed, axisLabelVisible: true, title: 'TP3' });
                    }
                };
            });
        });
    </script>
</body>
</html>
