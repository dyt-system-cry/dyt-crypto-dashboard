<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

class BinanceService
{
    protected $baseUrl = 'https://api.binance.com/api/v3';

    public function getKlines(string $symbol, string $interval, int $limit = 200)
    {
        $cacheKey = "binance_klines_{$symbol}_{$interval}";
        // Cache for 30 seconds to avoid rate limits
        return Cache::remember($cacheKey, 30, function () use ($symbol, $interval, $limit) {
            $response = Http::get("{$this->baseUrl}/klines", [
                'symbol' => strtoupper($symbol),
                'interval' => $interval,
                'limit' => $limit
            ]);

            if ($response->successful()) {
                return $this->formatKlines($response->json());
            }

            throw new \Exception("Failed to fetch data from Binance API");
        });
    }

    protected function formatKlines($klines)
    {
        return array_map(function ($k) {
            return [
                'open_time' => $k[0],
                'open' => (float)$k[1],
                'high' => (float)$k[2],
                'low' => (float)$k[3],
                'close' => (float)$k[4],
                'volume' => (float)$k[5],
                'close_time' => $k[6],
            ];
        }, $klines);
    }
}
