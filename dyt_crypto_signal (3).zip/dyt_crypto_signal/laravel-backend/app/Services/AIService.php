<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;

class AIService
{
    protected $aiEndpoint = 'http://127.0.0.1:8000';

    public function getPrediction(string $symbol, array $klines)
    {
        try {
            // Use last 100 klines for the ML model
            $response = Http::timeout(3)->post("{$this->aiEndpoint}/api/predict/{$symbol}", [
                'symbol' => $symbol,
                'timeframe' => '15m',
                'data' => array_slice($klines, -100)
            ]);

            if ($response->successful()) {
                return $response->json();
            }
        } catch (\Exception $e) {
            // Log fallback error
        }

        return ['prediction' => 'NEUTRAL', 'confidence' => 0];
    }
}
