<?php

namespace App\Services;

class SignalService
{
    public function generateSignal(string $symbol, $strategyResult, $aiResult, array $klines15m)
    {
        $techSignal = $strategyResult['signal'] ?? 'NEUTRAL';
        $aiSignal = $aiResult['prediction'] ?? 'NEUTRAL';
        
        $finalSignal = 'NEUTRAL';
        
        // AI combination rule
        if ($techSignal === 'BUY' && $aiSignal === 'BUY') {
            $finalSignal = 'STRONG BUY';
        } elseif ($techSignal === 'SELL' && $aiSignal === 'SELL') {
            $finalSignal = 'STRONG SELL';
        } elseif ($techSignal !== 'NEUTRAL') {
            $finalSignal = $techSignal;
        }

        $currentPrice = end($klines15m)['close'];
        $atr = 0.02 * $currentPrice; // Fallback naive ATR (2% volatility assumption)
        
        // Risk Management Calculations
        $entry = $currentPrice;
        $sl = null;
        $tp1 = null;
        $tp2 = null;

        if (str_contains($finalSignal, 'BUY')) {
            $sl = round($entry - ($atr * 1.5), 2);
            $tp1 = round($entry + ($atr * 1.5), 2);
            $tp2 = round($entry + ($atr * 3.0), 2);
        } elseif (str_contains($finalSignal, 'SELL')) {
            $sl = round($entry + ($atr * 1.5), 2);
            $tp1 = round($entry - ($atr * 1.5), 2);
            $tp2 = round($entry - ($atr * 3.0), 2);
        }

        return [
            'symbol' => $symbol,
            'signal' => $finalSignal,
            'entry' => $entry,
            'sl' => $sl,
            'tp1' => $tp1,
            'tp2' => $tp2,
            'tech_signal' => $techSignal,
            'ai_signal' => $aiSignal,
            'ai_confidence' => $aiResult['confidence'] ?? 0,
            'metadata' => [
                'rsi' => $strategyResult['rsi'] ?? 50,
                'bb_upper' => $strategyResult['bb']['upper'] ?? 0,
                'bb_lower' => $strategyResult['bb']['lower'] ?? 0,
                'ema_200' => $strategyResult['ema200'] ?? 0,
                'volume_spike' => $strategyResult['volumeSpike'] ?? false,
                'reason' => $strategyResult['reason'] ?? 'None',
            ]
        ];
    }
}
