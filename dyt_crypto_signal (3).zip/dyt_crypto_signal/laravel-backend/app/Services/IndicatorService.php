<?php

namespace App\Services;

class IndicatorService
{
    public function calculateRSI(array $closes, int $period = 14)
    {
        $n = count($closes);
        if ($n <= $period) return null;

        $gains = 0;
        $losses = 0;

        for ($i = 1; $i <= $period; $i++) {
            $change = $closes[$i] - $closes[$i - 1];
            if ($change >= 0) $gains += $change;
            else $losses -= $change;
        }

        $avgGain = $gains / $period;
        $avgLoss = $losses / $period;

        $rsis = [];
        for ($i = $period; $i < $n; $i++) {
            if ($i > $period) {
                $change = $closes[$i] - $closes[$i - 1];
                $gain = $change >= 0 ? $change : 0;
                $loss = $change < 0 ? -$change : 0;

                $avgGain = (($avgGain * ($period - 1)) + $gain) / $period;
                $avgLoss = (($avgLoss * ($period - 1)) + $loss) / $period;
            }

            $rs = $avgLoss == 0 ? 100 : $avgGain / $avgLoss;
            $rsi = 100 - (100 / (1 + $rs));
            $rsis[] = $rsi;
        }

        return round(end($rsis), 2);
    }

    public function calculateBollingerBands(array $closes, int $period = 20, int $multiplier = 2)
    {
        $n = count($closes);
        if ($n < $period) return null;

        $slice = array_slice($closes, -$period);
        $sma = array_sum($slice) / $period;

        $variance = 0;
        foreach ($slice as $close) {
            $variance += pow($close - $sma, 2);
        }
        $stdDev = sqrt($variance / $period);

        return [
            'upper' => round($sma + ($multiplier * $stdDev), 2),
            'middle' => round($sma, 2),
            'lower' => round($sma - ($multiplier * $stdDev), 2),
        ];
    }

    public function calculateEMA(array $closes, int $period = 200)
    {
        $n = count($closes);
        if ($n < $period) return null;

        $sma = array_sum(array_slice($closes, 0, $period)) / $period;
        $multiplier = 2 / ($period + 1);

        $ema = $sma;
        for ($i = $period; $i < $n; $i++) {
            $ema = ($closes[$i] - $ema) * $multiplier + $ema;
        }

        return round($ema, 2);
    }
}
