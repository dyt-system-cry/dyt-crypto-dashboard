<?php

namespace App\Services;

class StrategyService
{
    protected $indicator;

    public function __construct(IndicatorService $indicator)
    {
        $this->indicator = $indicator;
    }

    public function analyze(array $klines15m, array $klines1h)
    {
        // Extract closes and volumes
        $closes15m = array_column($klines15m, 'close');
        $volumes15m = array_column($klines15m, 'volume');
        $currentClose = end($closes15m);

        $closes1h = array_column($klines1h, 'close');
        
        $rsi = $this->indicator->calculateRSI($closes15m);
        $bb = $this->indicator->calculateBollingerBands($closes15m);
        $ema200 = $this->indicator->calculateEMA($closes15m);

        // Calculate Average Volume
        $recentVols = array_slice($volumes15m, -20);
        $avgVol = count($recentVols) > 0 ? array_sum($recentVols) / count($recentVols) : 0;
        $currentVol = end($volumes15m);
        
        $volumeSpike = $currentVol > ($avgVol * 1.5);

        $signal = "NEUTRAL";
        $reason = "No conditions met";
        
        // EMA 200 Filter
        $trendDistance = 0;
        if ($ema200) {
            $trendDistance = abs($currentClose - $ema200) / $ema200;
        }
        
        if ($trendDistance > 0.10) {
            return ['signal' => 'NEUTRAL', 'reason' => 'Trend too strong (EMA200 % distance > 10%)'];
        }

        // 1H confirmation
        $rsi1h = $this->indicator->calculateRSI($closes1h);

        $isOversold = $rsi < 30 && $rsi1h < 45;
        $isOverbought = $rsi > 70 && $rsi1h > 55;

        // Antigravity Strategy conditions
        if ($isOversold && $currentClose < $bb['lower'] && $volumeSpike) {
            $signal = "BUY";
            $reason = "Oversold, below lower BB, volume spike";
        } elseif ($isOverbought && $currentClose > $bb['upper'] && $volumeSpike) {
            $signal = "SELL";
            $reason = "Overbought, above upper BB, volume spike";
        }

        return [
            'signal' => $signal,
            'reason' => $reason,
            'rsi' => $rsi,
            'bb' => $bb,
            'ema200' => $ema200,
            'rsi1h' => $rsi1h,
            'volumeSpike' => $volumeSpike
        ];
    }
}
