<?php

namespace App\Http\Controllers;

use App\Services\BinanceService;
use App\Services\StrategyService;
use App\Services\AIService;
use App\Services\SignalService;
use Illuminate\Http\Request;
use Exception;

class SignalController extends Controller
{
    protected BinanceService $binance;
    protected StrategyService $strategy;
    protected AIService $ai;
    protected SignalService $signal;

    public function __construct(
        BinanceService $binance,
        StrategyService $strategy,
        AIService $ai,
        SignalService $signal
    ) {
        $this->binance = $binance;
        $this->strategy = $strategy;
        $this->ai = $ai;
        $this->signal = $signal;
    }

    public function getSignal($symbol)
    {
        try {
            // Fetch Klines
            $klines15m = $this->binance->getKlines($symbol, '15m', 200);
            $klines1h = $this->binance->getKlines($symbol, '1h', 200);

            // Technical Strategy Analysis
            $strategyResult = $this->strategy->analyze($klines15m, $klines1h);

            // AI Prediction
            $aiResult = $this->ai->getPrediction($symbol, $klines15m);

            // Combine and Generate Signal
            $finalSignal = $this->signal->generateSignal($symbol, $strategyResult, $aiResult, $klines15m);

            return response()->json([
                'success' => true,
                'data' => $finalSignal
            ]);
        } catch (Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
