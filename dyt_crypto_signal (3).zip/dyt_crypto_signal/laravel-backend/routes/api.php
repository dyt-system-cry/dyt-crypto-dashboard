<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SignalController;

Route::get('/signal/{symbol}', [SignalController::class, 'getSignal']);
