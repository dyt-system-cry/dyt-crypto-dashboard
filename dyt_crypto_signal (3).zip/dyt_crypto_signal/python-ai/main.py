from fastapi import FastAPI, Query
from pydantic import BaseModel
from typing import List, Dict, Any
import numpy as np
import random
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Crypto AI Prediction Service")

# Allow CORS for local dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class KlineData(BaseModel):
    open: float
    high: float
    low: float
    close: float
    volume: float

class PredictionRequest(BaseModel):
    symbol: str
    timeframe: str
    data: List[KlineData]

@app.post("/api/predict/{symbol}")
async def predict_signal(symbol: str, request: PredictionRequest):
    """
    Simulated AI Prediction Endpoint.
    Analyzes recent kline data to predict future price movement.
    """
    
    # Calculate a mock confidence based on dummy logic
    confidence = round(random.uniform(65.0, 95.0), 2)
    
    # Very rudimentary logic to mock ML: 
    # If the last close is higher than the first close, lean BUY
    if len(request.data) > 0:
        first_close = request.data[0].close
        last_close = request.data[-1].close
        direction = "BUY" if last_close > first_close else "SELL"
    else:
        direction = random.choice(["BUY", "SELL", "NEUTRAL"])
    
    return {
        "symbol": symbol,
        "prediction": direction,
        "confidence": confidence,
        "model": "Antigravity-v1-Placeholder"
    }

@app.get("/health")
def health_check():
    return {"status": "ok"}
